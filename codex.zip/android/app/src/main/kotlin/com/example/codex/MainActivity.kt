package com.example.codex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
